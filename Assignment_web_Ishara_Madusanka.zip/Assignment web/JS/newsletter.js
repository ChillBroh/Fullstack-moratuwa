function newsletter(){
    let mail = document.getElementById("email").value;
    alert("Thank You for Subscribing to our News Letter. Your Email " + mail + " has been successfully added to our Website");
}